-- Consultar dba_tablespaces
SELECT * FROM dba_tablespaces;
 
--Consultar ruta en el servidor DB dba_data_files
select * from dba_data_files where tablespace_name IN ('CONV_REG_CRC_DATA','CONV_REG_CRC_INDX'); --SIMS_INDEX2 SIMS_DATOS



--Crear TableSpace 
--/u02/oradata/sgdesrel/datafiles/
CREATE TABLESPACE SIMS_DATOS4 DATAFILE 
  '/u02/oradata/sgdesrel/datafiles/SIMS_DATOS4_01.dbf' SIZE 128M AUTOEXTEND ON NEXT 128M MAXSIZE UNLIMITED
  
LOGGING
ONLINE
EXTENT MANAGEMENT LOCAL AUTOALLOCATE
BLOCKSIZE 8K
SEGMENT SPACE MANAGEMENT AUTO
FLASHBACK ON;




--Crear Indices
--/u02/oradata/sgdesrel/indexfiles/
CREATE TABLESPACE SIMS_TEMPFIBI_IDX DATAFILE 
  '/u02/oradata/sgdesrel/indexfiles/SIMS_TEMPFIBI_idx_01.dbf' SIZE 5M AUTOEXTEND ON NEXT 256M MAXSIZE UNLIMITED
LOGGING
ONLINE
EXTENT MANAGEMENT LOCAL AUTOALLOCATE
BLOCKSIZE 8K
SEGMENT SPACE MANAGEMENT AUTO
FLASHBACK ON;


