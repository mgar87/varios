

/*
AUTOR: MAURICIO GARCIA
FECHA: 18/07/2019
TICKET: 482556  GICO EGRESO AUTOMATICO
DESCRIPCION: Bloque anonimo que permite cambiar la hora de los movimientos transaccionales
             correspondientes al pago de los giros controlados que al momento de 
             ejecutar el job de cartera, quedaron con la hora de la madrugada.
*/


SET SERVEROUTPUT ON



DECLARE


--CONFIGURACION PARAMETROS
VNU_HORAS_AUMENTO NUMBER := 12; -- VALOR NUMERICO EN HORAS QUE CORRESPONDE AL AJUSTE DE LA HORA DE LOS
                                -- MOVIMIENTOS CORRESPONDIENTES AL PAGO CONTROLADO.
                                -- EJ: SI SE PARAMETRIZA EN 12, ENTONCES LOS MOVIMIENTOS QUE QUEDARON
                                -- REGISTRADOS A LAS 2:00 AM, CAMBIARAN A LAS 2:00 PM

VCA_HORA_MAXIMA  VARCHAR2(5) := '03:00'; -- CORRESPONDE AL RANGO DE HORA MAXIMO DESDE LA CUAL SE BUSCARA LOS MOVIMIENTOS 
                                         -- PARTIENDO DESDE LAS 00:00 HORAS
                                         -- EJEMPLO: SI SE ASIGNA LA HORA 03:00 ENTONCES BUSCARA LOS MOVIMIENTOS DE LOS
                                         -- PINES ESPECIFICADOS QUE TENGAN TRANSACCIONES DESDE LAS 00:00 AM HASTA 03:00 AM


vrg_trx       TRANSACCIONES_X_DOCUMENTOS%rowtype;
var_strings   PKGU_UTILIDAD.TYARRAY;
vca_pines     CLOB;
vca_texto     VARCHAR2(1000);
vca_error     VARCHAR2(1000);
vnu_contador  NUMBER := 1;
vnu_commit    NUMBER := 1;
cur_mvc       pkgb_movimientos_cajas.tp_movimientos_cajas;
vrg_mvc       movimientos_cajas%ROWTYPE;
vrg_med       movimientos_estados_documentos%ROWTYPE;

CURSOR cur_validapago (prg_trx  TRANSACCIONES_X_DOCUMENTOS%rowtype,
                       pca_hora VARCHAR2) IS
SELECT COUNT(1)
FROM  Movimientos_Cajas mvc
WHERE mvc.TRXDC_EMPRE_ID       = prg_trx.EMPRE_ID AND
      mvc.TRXDC_CODOC_GRPCO_ID = prg_trx.CODOC_GRPCO_ID AND
      mvc.TRXDC_CODOC_DOCUM_ID = prg_trx.CODOC_DOCUM_ID AND
      mvc.TRXDC_CONSECUTIVO    = prg_trx.CONSECUTIVO AND
      mvc.CONCE_ID = 1 AND
      TO_DATE(TO_CHAR(mvc.FECHASYS,'HH24:MI'),'HH24:MI')  < TO_DATE(pca_hora,'HH24:MI');
      
CURSOR cur_horapago (prg_trx  TRANSACCIONES_X_DOCUMENTOS%rowtype) IS
SELECT TO_CHAR(TO_DATE(mvc.hora,'HH24:MI:SS'),'HH24:MI') 
FROM  Movimientos_Cajas mvc
WHERE mvc.TRXDC_EMPRE_ID       = prg_trx.EMPRE_ID AND
      mvc.TRXDC_CODOC_GRPCO_ID = prg_trx.CODOC_GRPCO_ID AND
      mvc.TRXDC_CODOC_DOCUM_ID = prg_trx.CODOC_DOCUM_ID AND
      mvc.TRXDC_CONSECUTIVO    = prg_trx.CONSECUTIVO AND
      mvc.CONCE_ID = 1;

vnu_validapago NUMBER;

vca_horapago VARCHAR2(5);

BEGIN

 

vca_texto := '[482556] Proceso ajuste  pines pagos controlados - INICIO: '||to_char(sysdate, 'DD/MM/YYYY HH24:MI:SS');

 pkgu_utilidad.prdb_validateonl('SIMS','SIMS');

  EXECUTE IMMEDIATE 'ALTER TRIGGER TRGIU_MOVICAJA DISABLE';     
  EXECUTE IMMEDIATE 'ALTER TRIGGER TRGBIU_MOVIESDO DISABLE';     

DBMS_LOB.CREATETEMPORARY(vca_pines,FALSE);


 dbms_lob.append(vca_pines,'1642521264102332672,12932821257105727439,185421253105230338,13706821255105951992,1651021264102533771,12938721257105615813,1849221264102384621,'||

'13177921269105667640,13520721257105726727,1864521253105232997,13652621251105505637,13331721257105663765,13703021246105674627,13304121262105090339,');



 var_strings := pkgu_utilidad.fndb_token_array(vca_pines ,',');  

  -- Recorre listado de pines especificados en vca_pines
  FOR i IN 1..var_strings.COUNT LOOP
  
   BEGIN 
   
   vca_texto := '[482556]-['||vnu_contador||'] Valida existencia  pin :'||var_strings(i) ||'    Fecha: '||to_char(sysdate, 'DD/MM/YYYY HH24:MI:SS');
   DBMS_OUTPUT.PUT_LINE(vca_texto);
  
   vrg_trx :=   pkgb_TRANSACCIONES_DOCUMENTOS.fndb_ConsultarPorRefCrtl(1, TO_NUMBER(var_strings(i)));
  
 
    IF(vrg_trx.ref_control IS NOT NULL) THEN
     vca_texto := '[482556]-['||vnu_contador||'] Consulta exitosa  pin :'||var_strings(i) ||'    Fecha: '||to_char(sysdate, 'DD/MM/YYYY HH24:MI:SS');
     DBMS_OUTPUT.PUT_LINE(vca_texto);
 
  
   OPEN cur_validapago(vrg_trx, VCA_HORA_MAXIMA);
   FETCH cur_validapago INTO vnu_validapago;
   CLOSE cur_validapago;
  
   
   IF (vnu_validapago > 0) THEN

  -- ACTUALIZA FECHA MOVIMIENTOS CAJAS
  UPDATE movimientos_cajas mvc
     SET mvc.hora  =  TO_CHAR(mvc.fechasys + NUMTODSINTERVAL(VNU_HORAS_AUMENTO, 'HOUR'),'HH24MISS'),
         mvc.fechasys =  mvc.fechasys + NUMTODSINTERVAL(VNU_HORAS_AUMENTO, 'HOUR')
   WHERE mvc.TRXDC_EMPRE_ID       = vrg_trx.EMPRE_ID 
     AND mvc.TRXDC_CODOC_GRPCO_ID = vrg_trx.CODOC_GRPCO_ID 
     AND mvc.TRXDC_CODOC_DOCUM_ID = vrg_trx.CODOC_DOCUM_ID 
     AND mvc.TRXDC_CONSECUTIVO    = vrg_trx.CONSECUTIVO 
     AND TO_DATE(TO_CHAR(mvc.FECHASYS,'HH24:MI'),'HH24:MI')  < TO_DATE(VCA_HORA_MAXIMA,'HH24:MI');
  
  -- ACTUALIZA MOVIIENTO ESTADOS DOCUMENTOS
  UPDATE movimientos_estados_documentos med
   SET med.hora =  TO_CHAR(med.fechasys + NUMTODSINTERVAL(VNU_HORAS_AUMENTO, 'HOUR'),'HH24MISS'),
       med.fechasys =  med.fechasys + NUMTODSINTERVAL(VNU_HORAS_AUMENTO, 'HOUR')
   WHERE med.TRXDC_EMPRE_ID       = vrg_trx.EMPRE_ID 
     AND   med.TRXDC_CODOC_GRPCO_ID = vrg_trx.CODOC_GRPCO_ID 
     AND   med.TRXDC_CODOC_DOCUM_ID = vrg_trx.CODOC_DOCUM_ID 
     AND   med.TRXDC_CONSECUTIVO    = vrg_trx.CONSECUTIVO 
     AND   TO_DATE(TO_CHAR(med.FECHASYS,'HH24:MI'),'HH24:MI')  < TO_DATE(VCA_HORA_MAXIMA,'HH24:MI');
		 
-- ACTUALIZA AUTORIZACION
  UPDATE autorizaciones au 
     SET au.FECHASYS_AUTORIZA =  au.fechasys_autoriza + NUMTODSINTERVAL(VNU_HORAS_AUMENTO, 'HOUR'),
	     au.FECHASYS =  au.fechasys + NUMTODSINTERVAL(VNU_HORAS_AUMENTO, 'HOUR'),
		 au.hora = TO_CHAR(au.fechasys + NUMTODSINTERVAL(VNU_HORAS_AUMENTO, 'HOUR'),'HH24MISS')
	 WHERE au.TRXDC_EMPRE_ID= vrg_trx.EMPRE_ID 
       AND au.TRXDC_CODOC_GRPCO_ID= vrg_trx.CODOC_GRPCO_ID 
       AND au.TRXDC_CODOC_DOCUM_ID= vrg_trx.CODOC_DOCUM_ID 
       AND au.TRXDC_CONSECUTIVO= vrg_trx.CONSECUTIVO
	   AND TO_DATE(TO_CHAR(au.FECHASYS,'HH24:MI'),'HH24:MI')  < TO_DATE(VCA_HORA_MAXIMA,'HH24:MI');
                                                                                   
 -- ACTUALIZA DISTRIBUCION CONCEPTOS
  UPDATE distribucion_conceptos dis
     SET FECHASYS = dis.fechasys + NUMTODSINTERVAL(VNU_HORAS_AUMENTO, 'HOUR')
   WHERE dis.TRXDC_EMPRE_ID       = vrg_trx.EMPRE_ID 
     AND dis.TRXDC_CODOC_GRPCO_ID = vrg_trx.CODOC_GRPCO_ID 
     AND dis.TRXDC_CODOC_DOCUM_ID = vrg_trx.CODOC_DOCUM_ID 
     AND dis.TRXDC_CONSECUTIVO    = vrg_trx.CONSECUTIVO 
     AND TO_DATE(TO_CHAR(dis.FECHASYS,'HH24:MI'),'HH24:MI')  < TO_DATE(VCA_HORA_MAXIMA,'HH24:MI');
  
  -- ACTUALIZA CONVENIO_REGISTRO_CRC
  UPDATE CONVENIO_REGISTRO_CRC
     SET concrchr =  TO_CHAR(TO_DATE(concrchr,'HH24MISS') + NUMTODSINTERVAL(VNU_HORAS_AUMENTO, 'HOUR'),'HH24MI')
   WHERE concrcrc = vrg_trx.ref_control
     AND TO_DATE(concrchr,'HH24MISS')  < TO_DATE(VCA_HORA_MAXIMA,'HH24:MI');
  
  
  -- ACTUALIZA MOVICONT TEMP
  UPDATE MOVICONT_TEMP mov
     SET mov.TERCFESI = mov.TERCFESI + NUMTODSINTERVAL(VNU_HORAS_AUMENTO, 'HOUR')
   WHERE mov.MOCODOTE = vrg_trx.ref_control
     AND mov.MOCODCTD = 1081
     AND TO_DATE(TO_CHAR(mov.TERCFESI,'HH24:MI'),'HH24:MI') < TO_DATE(VCA_HORA_MAXIMA,'HH24:MI');
     
  
  -- ACTUALIZA MOVICAPA
  UPDATE MOVICAPA mv--MOCPFESI
     SET mv.MOCPFESI = mv.MOCPFESI + NUMTODSINTERVAL(VNU_HORAS_AUMENTO, 'HOUR'),
         mv.MOCPFEMO = mv.MOCPFEMO + NUMTODSINTERVAL(VNU_HORAS_AUMENTO, 'HOUR')
   WHERE mv.MOCPEMPR = vrg_trx.EMPRE_ID
     AND mv.MOCPGRPO = vrg_trx.CODOC_GRPCO_ID
     AND mv.MOCPDOCU = vrg_trx.CODOC_DOCUM_ID
     AND mv.MOCPCONS = vrg_trx.CONSECUTIVO
     AND mv.MOCPESTA = 38
     AND TO_DATE(TO_CHAR(mv.MOCPFESI,'HH24:MI'),'HH24:MI') < TO_DATE(VCA_HORA_MAXIMA,'HH24:MI');  
	 
  -- ACTUALIZA HIDABATR
  UPDATE HIDABATR hd
     SET hd.HIDAFECH = hd.HIDAFECH + NUMTODSINTERVAL(VNU_HORAS_AUMENTO, 'HOUR')
	WHERE hd.HIDARECO = vrg_trx.ref_control 
	  AND hd.HIDATIOP = 2 -- pago
	  AND TO_DATE(TO_CHAR(hd.HIDAFECH,'HH24:MI'),'HH24:MI') < TO_DATE(VCA_HORA_MAXIMA,'HH24:MI');  
       
   ELSE
   
    OPEN cur_horapago(vrg_trx);
    FETCH cur_horapago INTO vca_horapago;
    CLOSE cur_horapago;
   
     vca_texto := '[482556]-['||vnu_contador||'] No se modifico pin :'||var_strings(i) ||' - No aplica Hora pago: ['||vca_horapago||']  -  Fecha: '||to_char(sysdate, 'DD/MM/YYYY HH24:MI:SS');
     DBMS_OUTPUT.PUT_LINE(vca_texto);
   END IF;
 
    
   
   ELSE
   
     vca_texto := '[482556]-['||vnu_contador||'] No existe pin [:'||var_strings(i) ||']    Fecha: '||to_char(sysdate, 'DD/MM/YYYY HH24:MI:SS');
     DBMS_OUTPUT.PUT_LINE(vca_texto);
   END IF;  
                         
              
   EXCEPTION 
     WHEN OTHERS THEN
           
     vca_error := '[482556] ERROR AL ACTUALIZAR ESTADO DEL PIN ['||var_strings(i)||'] - ERROR CODIGO: '||SQLCODE||' - '||SQLERRM||' | DESCRIPCION: '||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
     DBMS_OUTPUT.PUT_LINE(vca_error); 
                   
   END;
 
 
  
  vca_texto := '[482556]-['||vnu_contador||'] Fin proceso actualizacion  pin :'||var_strings(i) ||'    Fecha: '||to_char(sysdate, 'DD/MM/YYYY HH24:MI:SS');
  DBMS_OUTPUT.PUT_LINE(vca_texto); 
  
   vnu_contador := vnu_contador + 1;
  vnu_commit := vnu_commit + 1;
  
  IF(vnu_commit = 100) THEN
    COMMIT;
    vnu_commit := 1;
  END IF;
 
  END LOOP;
 
  -- Liberacion recursos objeto temporal
  DBMS_LOB.FREETEMPORARY(vca_pines);
 
  vca_texto := '[482556] FIN Proceso ajuste  pines pagos controlados - FECHA: '||to_char(sysdate, 'DD/MM/YYYY HH24:MI:SS');
  DBMS_OUTPUT.PUT_LINE(vca_texto); 

 EXECUTE IMMEDIATE 'ALTER TRIGGER TRGIU_MOVICAJA ENABLE'; 
 EXECUTE IMMEDIATE 'ALTER TRIGGER TRGBIU_MOVIESDO ENABLE'; 
 COMMIT;
EXCEPTION
 WHEN OTHERS THEN
   ROLLBACK;
   EXECUTE IMMEDIATE 'ALTER TRIGGER TRGIU_MOVICAJA ENABLE'; 
   EXECUTE IMMEDIATE 'ALTER TRIGGER TRGBIU_MOVIESDO ENABLE'; 
   vca_error := 'ERROR GENERAL: SQLCODE: '||SQLCODE|| ' - SQLERRORM: '||sqlerrm||' - TRAZA: '|| DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
   DBMS_OUTPUT.PUT_LINE(vca_error);

END;




